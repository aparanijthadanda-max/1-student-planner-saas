const form = document.querySelector("#marks-form");
const resultSection = document.querySelector("#result");
const errorMessage = document.querySelector("#error-message");

const subjects = [
  { id: "maths", name: "Mathematics" },
  { id: "science", name: "Science" },
  { id: "english", name: "English" },
  { id: "social", name: "Social Studies" },
  { id: "computer", name: "Computer Science" }
];

function getGrade(percentage) {
  if (percentage >= 90) return "A";
  if (percentage >= 80) return "B";
  if (percentage >= 70) return "C";
  if (percentage >= 60) return "D";
  if (percentage >= 40) return "E";
  return "F";
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  errorMessage.textContent = "";

  const marks = [];
  for (const subject of subjects) {
    const input = document.getElementById(subject.id);
    const value = input.value.trim();

    if (value === "") {
      errorMessage.textContent = `Please enter marks for ${subject.name}.`;
      input.focus();
      resultSection.hidden = true;
      return;
    }

    const mark = Number(value);
    if (!Number.isFinite(mark) || mark < 0 || mark > 100) {
      errorMessage.textContent = `${subject.name} marks must be between 0 and 100.`;
      input.focus();
      resultSection.hidden = true;
      return;
    }

    marks.push(mark);
  }

  const total = marks.reduce((sum, mark) => sum + mark, 0);
  const percentage = total / marks.length;
  const average = percentage;
  const grade = getGrade(percentage);
  const passed = marks.every((mark) => mark >= 35);

  const studentName = document.getElementById("student-name").value.trim();
  document.getElementById("result-student").textContent =
    studentName ? `Result for ${studentName}` : "Your result";
  document.getElementById("total").textContent = `${total} / 500`;
  document.getElementById("percentage").textContent = `${percentage.toFixed(2)}%`;
  document.getElementById("average").textContent = average.toFixed(2);
  document.getElementById("grade").textContent = grade;

  const status = document.getElementById("status");
  status.textContent = passed ? "Result: PASS" : "Result: FAIL — score at least 35 in every subject to pass.";
  status.className = `status ${passed ? "pass" : "fail"}`;

  resultSection.hidden = false;
  resultSection.scrollIntoView({ behavior: "smooth", block: "nearest" });
});

form.addEventListener("reset", () => {
  errorMessage.textContent = "";
  resultSection.hidden = true;
});
