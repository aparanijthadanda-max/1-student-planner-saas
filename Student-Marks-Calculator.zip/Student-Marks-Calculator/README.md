# Student Marks Calculator

A beginner-friendly student project built with **HTML, CSS, and JavaScript**. Enter marks for five subjects to calculate total marks, percentage, average, grade, and pass/fail status.

## Features

- Student name field
- Marks input for five subjects (0–100 each)
- Calculates total out of 500
- Calculates percentage and average
- Assigns a grade from A to F
- Checks pass/fail status (minimum 35 in every subject)
- Validates marks and shows helpful error messages
- Responsive layout for desktop and mobile
- Clear button to reset the form

## Grade scale

| Percentage | Grade |
|---|---|
| 90–100% | A |
| 80–89.99% | B |
| 70–79.99% | C |
| 60–69.99% | D |
| 40–59.99% | E |
| Below 40% | F |

The student must score at least 35 marks in each subject to pass. This is a sample grading scale for the project; change it to match your school's rules if needed.

## Project structure

```text
Student-Marks-Calculator/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── README.md
```

## How to run

1. Download or clone this repository.
2. Open `index.html` in a web browser.
3. Enter the marks for all five subjects.
4. Select **Calculate Result**.

No installation or external libraries are required.

## Upload to GitHub

1. Sign in to [GitHub](https://github.com/).
2. Select **New repository**.
3. Enter the repository name `Student-Marks-Calculator`.
4. Choose Public or Private, then create the repository.
5. Select **Add file → Upload files**.
6. Upload `index.html`, `README.md`, and the `css` and `js` folders with their files.
7. Select **Commit changes**.

## Technologies used

- HTML5
- CSS3
- JavaScript

## License

You may use and modify this project for learning and educational purposes.
